from typing import Optional
from pydantic import BaseModel, ConfigDict


class ProfileResponse(BaseModel):
    profile_id: int
    user_id: int
    username: Optional[str] = None
    profile_pic_url: Optional[str] = None
    bio: Optional[str] = None
    location: Optional[str] = None
    followers_count: int = 0
    following_count: int = 0
    posts_count: int = 0
    account_type: str = "influencer"
    total_reach: int = 0
    total_earned: float = 0.0

    model_config = ConfigDict(from_attributes=True)


class NotificationResponse(BaseModel):
    id: int
    user_id: int
    type: str
    message: Optional[str] = None
    reference_id: Optional[int] = None
    is_read: bool = False
    created_at: str 
    actor_id: Optional[int] = None      
    actor_username: Optional[str] = None 

    model_config = ConfigDict(from_attributes=True)


class FollowResponse(BaseModel):
    id: Optional[int] = None
    follower_id: int
    following_id: int
    user_name: Optional[str] = None
    is_following: Optional[bool] = True
    followers_count: Optional[int] = 0

    model_config = ConfigDict(from_attributes=True)

