import base64
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import and_, desc, func, or_
from sqlalchemy.orm import Session, joinedload, selectinload

from app.common.models.social import Notification, Follow, CloseFriend
from app.common.models.moderation import UserBlock
from app.common.models.story import (
    Story,
    StoryLike,
    StoryMention,
    StoryMute,
    StoryReply,
    StoryReport,
    StorySave,
    StoryShare,
    StoryView,
)
from app.common.models.user import User
from app.common.models.messaging import DirectMessage, MESSAGE_KIND_STORY_REACTION, MESSAGE_KIND_STORY_REPLY
from app.common.services.message_service import MessageService
from app.common.services.music_service import MusicService
from app.common.schemas.story import (
    ActivityLiker,
    ActivityViewer,
    StoryActivityResponse,
    StoryBatchResponse,
    StoryGroupResponse,
    StoryItemResponse,
    StoryMentionItem,
    StoryReplyResponse,
    StoryReshareRequest,
    StoryShareResponse,
    StorySlideResponse,
    StoryUserResponse,
    MentionUserSearchItem,
)

logger = logging.getLogger("talktamila.story_service")

DEFAULT_DURATION_HOURS = 24
VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v"}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def format_iso(dt: Optional[datetime]) -> Optional[str]:
    if not dt:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc).isoformat()
    return dt.isoformat()


def make_naive(dt: datetime) -> datetime:
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def get_time_ago(dt: Optional[datetime]) -> str:
    if not dt:
        return "Just now"
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    diff = now - dt
    seconds = max(0, int(diff.total_seconds()))
    if seconds < 60:
        return "Just now"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    return f"{days}d ago"


async def file_to_base64_data_url(file: UploadFile) -> Tuple[str, str]:
    content = await file.read()
    if not content:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uploaded file is empty.",
        )

    ext = os.path.splitext(file.filename or "")[1].lower()
    content_type = file.content_type

    if not content_type or content_type == "application/octet-stream":
        if ext in VIDEO_EXTENSIONS:
            content_type = "video/mp4"
        elif ext == ".png":
            content_type = "image/png"
        elif ext == ".gif":
            content_type = "image/gif"
        elif ext == ".webp":
            content_type = "image/webp"
        else:
            content_type = "image/jpeg"

    media_type = "video" if ("video" in content_type or ext in VIDEO_EXTENSIONS) else "image"
    b64 = base64.b64encode(content).decode("ascii")
    data_url = f"data:{content_type};base64,{b64}"
    return data_url, media_type


def fetch_batch_story_stats(story_ids: List[int], current_user_id: Optional[int], db: Session) -> Dict[str, Any]:
    if not story_ids:
        return {
            "views": {},
            "likes": {},
            "replies": {},
            "shares": {},
            "viewed_by_me": set(),
            "liked_by_me": set(),
        }

    views_rows = db.query(StoryView.story_id, func.count(func.distinct(StoryView.user_id))).filter(StoryView.story_id.in_(story_ids)).group_by(StoryView.story_id).all()
    likes_rows = db.query(StoryLike.story_id, func.count(func.distinct(StoryLike.user_id))).filter(StoryLike.story_id.in_(story_ids)).group_by(StoryLike.story_id).all()
    replies_rows = db.query(StoryReply.story_id, func.count(StoryReply.reply_id)).filter(StoryReply.story_id.in_(story_ids)).group_by(StoryReply.story_id).all()
    shares_rows = db.query(StoryShare.story_id, func.count(StoryShare.share_id)).filter(StoryShare.story_id.in_(story_ids)).group_by(StoryShare.story_id).all()

    viewed_by_me = set()
    liked_by_me = set()
    if current_user_id:
        v_rows = db.query(StoryView.story_id).filter(StoryView.story_id.in_(story_ids), StoryView.user_id == current_user_id).all()
        viewed_by_me = {r[0] for r in v_rows}
        l_rows = db.query(StoryLike.story_id).filter(StoryLike.story_id.in_(story_ids), StoryLike.user_id == current_user_id).all()
        liked_by_me = {r[0] for r in l_rows}

    return {
        "views": {r[0]: r[1] for r in views_rows},
        "likes": {r[0]: r[1] for r in likes_rows},
        "replies": {r[0]: r[1] for r in replies_rows},
        "shares": {r[0]: r[1] for r in shares_rows},
        "viewed_by_me": viewed_by_me,
        "liked_by_me": liked_by_me,
    }


def extract_mentioned_usernames(text: Optional[str]) -> List[str]:
    if not text:
        return []
    matches = re.findall(r"@([a-zA-Z0-9_]+)", text)
    seen = set()
    result = []
    for m in matches:
        low = m.lower()
        if low not in seen:
            seen.add(low)
            result.append(m)
    return result


def process_and_create_mentions(
    db: Session,
    story: Story,
    mentions_payload: Optional[List[Any]],
    caption: Optional[str],
    current_user: User,
) -> List[StoryMention]:
    candidate_user_ids = set()
    candidate_usernames = set()
    coords_by_uid = {}
    coords_by_uname = {}

    if mentions_payload:
        for m in mentions_payload:
            uid = getattr(m, "user_id", None) if hasattr(m, "user_id") else (m.get("user_id") if isinstance(m, dict) else None)
            uname = getattr(m, "username", None) if hasattr(m, "username") else (m.get("username") if isinstance(m, dict) else None)
            x = getattr(m, "x", None) if hasattr(m, "x") else (m.get("x") if isinstance(m, dict) else None)
            y = getattr(m, "y", None) if hasattr(m, "y") else (m.get("y") if isinstance(m, dict) else None)
            if uid:
                candidate_user_ids.add(int(uid))
                coords_by_uid[int(uid)] = (x, y)
            if uname:
                clean_uname = uname.strip().lstrip("@").lower()
                candidate_usernames.add(clean_uname)
                coords_by_uname[clean_uname] = (x, y)

    caption_unames = extract_mentioned_usernames(caption)
    for u in caption_unames:
        candidate_usernames.add(u.strip().lstrip("@").lower())

    if not candidate_user_ids and not candidate_usernames:
        return []

    query_conds = []
    if candidate_user_ids:
        query_conds.append(User.user_id.in_(list(candidate_user_ids)))
    if candidate_usernames:
        query_conds.append(func.lower(User.username).in_(list(candidate_usernames)))

    target_users = db.query(User).filter(or_(*query_conds), User.is_active.is_(True)).all()
    created_mentions = []

    for target in target_users:
        # Check blocking
        is_blocked = db.query(UserBlock).filter(
            or_(
                and_(UserBlock.blocker_id == current_user.id, UserBlock.blocked_id == target.user_id),
                and_(UserBlock.blocker_id == target.user_id, UserBlock.blocked_id == current_user.id),
            )
        ).first() is not None

        if is_blocked:
            if mentions_payload:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Cannot mention @{target.username}: user is blocked."
                )
            continue

        x, y = coords_by_uid.get(target.user_id, coords_by_uname.get((target.username or "").lower(), (None, None)))

        existing = db.query(StoryMention).filter(
            StoryMention.story_id == story.story_id,
            StoryMention.mentioned_user_id == target.user_id,
        ).first()

        if not existing:
            mention = StoryMention(
                story_id=story.story_id,
                mentioned_user_id=target.user_id,
                created_by_user_id=current_user.id,
                x=x,
                y=y,
                created_at=make_naive(utc_now()),
            )
            db.add(mention)
            created_mentions.append(mention)

            # Send Notification ONLY to mentioned user (STORY_MENTION)
            if target.user_id != current_user.id:
                notif = Notification(
                    user_id=target.user_id,
                    type="STORY_MENTION",
                    message=f"{current_user.username} mentioned you in their story",
                    reference_id=story.story_id,
                    is_read=False,
                    created_at=make_naive(utc_now()),
                )
                db.add(notif)

    db.commit()
    return created_mentions


def is_story_root_active(s: Story, db: Session, now_naive: datetime) -> bool:
    if not s.original_story_id or s.original_story_id == s.story_id:
        return True
    root = s.original_story or db.get(Story, s.original_story_id)
    if not root or root.is_deleted or (root.expires_at and root.expires_at <= now_naive):
        return False
    return True


def build_story_item(
    story: Story,
    current_user_id: Optional[int],
    db: Session,
    batch_stats: Optional[Dict[str, Any]] = None,
) -> StoryItemResponse:
    if batch_stats is not None:
        views_count = batch_stats["views"].get(story.story_id, 0)
        likes_count = batch_stats["likes"].get(story.story_id, 0)
        replies_count = batch_stats["replies"].get(story.story_id, 0)
        shares_count = batch_stats["shares"].get(story.story_id, 0)
        viewed_by_me = story.story_id in batch_stats["viewed_by_me"]
        liked_by_me = story.story_id in batch_stats["liked_by_me"]
    else:
        views_count = db.query(func.count(func.distinct(StoryView.user_id))).filter(StoryView.story_id == story.story_id).scalar() or 0
        likes_count = db.query(func.count(func.distinct(StoryLike.user_id))).filter(StoryLike.story_id == story.story_id).scalar() or 0
        replies_count = db.query(func.count(StoryReply.reply_id)).filter(StoryReply.story_id == story.story_id).scalar() or 0
        shares_count = db.query(func.count(StoryShare.share_id)).filter(StoryShare.story_id == story.story_id).scalar() or 0

        viewed_by_me = False
        liked_by_me = False
        if current_user_id:
            viewed_by_me = (
                db.query(StoryView.view_id)
                .filter(StoryView.story_id == story.story_id, StoryView.user_id == current_user_id)
                .first()
                is not None
            )
            liked_by_me = (
                db.query(StoryLike.story_likes_id)
                .filter(StoryLike.story_id == story.story_id, StoryLike.user_id == current_user_id)
                .first()
                is not None
            )

    owner_data = None
    if story.owner:
        owner_data = StoryUserResponse(
            id=story.owner.id,
            user_id=story.owner.id,
            username=story.owner.username or f"user_{story.owner.id}",
            avatar=story.owner.avatar_url,
            avatar_url=story.owner.avatar_url,
            full_name=story.owner.full_name or story.owner.username,
            role=story.owner.role or "influencer",
            verified=story.owner.role in ("influencer", "admin"),
        )

    original_owner_data = None
    orig_username = None
    if story.original_owner_id:
        orig_user = story.original_owner or db.get(User, story.original_owner_id)
        if orig_user:
            orig_username = orig_user.username
            original_owner_data = StoryUserResponse(
                id=orig_user.id,
                user_id=orig_user.id,
                username=orig_user.username or f"user_{orig_user.id}",
                avatar=orig_user.avatar_url,
                avatar_url=orig_user.avatar_url,
                full_name=orig_user.full_name or orig_user.username,
                role=orig_user.role or "influencer",
                verified=orig_user.role in ("influencer", "admin"),
            )

    mentions_data: List[StoryMentionItem] = []
    mentions_list = story.mentions if hasattr(story, "mentions") and story.mentions is not None else db.query(StoryMention).filter(StoryMention.story_id == story.story_id).all()
    for m in mentions_list:
        m_user = m.mentioned_user or db.get(User, m.mentioned_user_id)
        mentions_data.append(
            StoryMentionItem(
                id=m.id,
                story_id=m.story_id,
                mentioned_user_id=m.mentioned_user_id,
                created_by_user_id=m.created_by_user_id,
                username=m_user.username if m_user else None,
                full_name=m_user.full_name if m_user else None,
                avatar_url=m_user.avatar_url if m_user else None,
                x=m.x,
                y=m.y,
            )
        )

    now_naive = make_naive(utc_now())
    is_active = (not story.is_deleted) and (story.expires_at is None or story.expires_at > now_naive)

    if story.original_story_id and story.original_story_id != story.story_id:
        root = story.original_story or db.get(Story, story.original_story_id)
        if not root or root.is_deleted or (root.expires_at and root.expires_at <= now_naive):
            is_active = False

    is_reshare = bool(story.parent_story_id or (story.original_story_id and story.original_story_id != story.story_id))

    can_reshare = False
    if current_user_id and current_user_id != story.user_id and is_active:
        is_mentioned = any(m.mentioned_user_id == current_user_id for m in mentions_data)
        can_reshare = is_mentioned or (normalize_audience(story.audience) == "PUBLIC")

    return StoryItemResponse(
        story_id=story.story_id,
        id=story.story_id,
        user_id=story.user_id,
        author_id=story.user_id,
        media_url=story.media_url,
        imageUrl=story.media_url,
        media_type=story.media_type or "image",
        created_at=format_iso(story.created_at) or utc_now().isoformat(),
        expires_at=format_iso(story.expires_at) or (utc_now() + timedelta(hours=24)).isoformat(),
        caption=story.caption,
        content=story.caption,
        audience=story.audience or "PUBLIC",
        is_active=is_active,
        has_active_story=is_active,
        music_id=story.music_id,
        music_title=story.music_title,
        music_artist=story.music_artist,
        music_url=story.music_url,
        music_thumbnail=story.music_thumbnail,
        music_duration=story.music_duration or 60.0,
        music_start_time=story.music_start_time or 0.0,
        likes_count=likes_count,
        replies_count=replies_count,
        views_count=views_count,
        shares_count=shares_count,
        viewed_by_me=viewed_by_me,
        liked_by_me=liked_by_me,
        username=story.owner.username if story.owner else f"user_{story.user_id}",
        user=owner_data,
        parent_story_id=story.parent_story_id,
        original_story_id=story.original_story_id,
        original_owner_id=story.original_owner_id,
        original_username=orig_username,
        original_user=original_owner_data,
        is_reshare=is_reshare,
        can_reshare=can_reshare,
        mentions=mentions_data,
        status=story.status or ("deleted" if story.is_deleted else ("expired" if not is_active else "active")),
    )


def normalize_audience(aud: Optional[Any], is_admin: bool = False) -> str:
    if is_admin:
        return "PUBLIC"
    if not aud:
        return "PUBLIC"
    val = aud.value if hasattr(aud, "value") else str(aud)
    val = val.strip().upper()
    if val in ("CLOSE", "CLOSE_FRIEND", "CLOSE_FRIENDS"):
        return "CLOSE_FRIENDS"
    if val in ("FOLLOWER", "FOLLOWERS"):
        return "FOLLOWERS"
    return "PUBLIC"


def story_to_slide(story_item: StoryItemResponse, creator_name: str) -> StorySlideResponse:
    music_label = None
    if story_item.music_title:
        music_label = f"{story_item.music_title} – {story_item.music_artist or 'Tamil Music'} 🎵"

    return StorySlideResponse(
        id=story_item.id,
        story_id=story_item.story_id,
        imageUrl=story_item.media_url,
        media_url=story_item.media_url,
        media_type=story_item.media_type,
        caption=story_item.caption,
        content=story_item.content,
        audience=story_item.audience or "PUBLIC",
        duration=5000,
        created_at=story_item.created_at,
        expires_at=story_item.expires_at,
        liked=story_item.liked_by_me,
        likes_count=story_item.likes_count,
        views_count=story_item.views_count,
        shares_count=story_item.shares_count,
        replies_count=story_item.replies_count,
        musicTrack=music_label,
        music_url=story_item.music_url,
        replyPlaceholder=f"Reply to {creator_name}...",
        parent_story_id=story_item.parent_story_id,
        original_story_id=story_item.original_story_id,
        original_owner_id=story_item.original_owner_id,
        original_username=story_item.original_username,
        is_reshare=story_item.is_reshare,
        can_reshare=story_item.can_reshare,
        mentions=story_item.mentions,
        status=story_item.status,
    )


class StoryService:
    @staticmethod
    def create_story(payload, current_user: User, db: Session) -> StoryItemResponse:
        """Create a story from a JSON payload (media_url or gradient already provided)."""
        media_url = getattr(payload, "media_url", None)
        caption = getattr(payload, "caption", None) or getattr(payload, "content", None)
        
        if not media_url:
            if caption:
                media_url = "gradient:insta"
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Either media_url or caption/content is required to create a story.",
                )

        media_type = (getattr(payload, "media_type", "image") or "image").strip().lower()
        if media_type not in ("image", "video", "text"):
            media_type = "image"

        duration_hours = getattr(payload, "duration_hours", DEFAULT_DURATION_HOURS) or DEFAULT_DURATION_HOURS
        now_naive = make_naive(utc_now())
        expires_naive = now_naive + timedelta(hours=duration_hours)

        music_id = getattr(payload, "music_id", None)
        music_title = getattr(payload, "music_title", None)
        music_artist = getattr(payload, "music_artist", None)
        music_url = getattr(payload, "music_url", None)
        music_thumbnail = getattr(payload, "music_thumbnail", None)
        music_duration = getattr(payload, "music_duration", 60.0) or 60.0
        music_start_time = getattr(payload, "music_start_time", 0.0) or 0.0

        resolved_music_id = None
        if music_id or music_title or music_url:
            resolved_music_id = MusicService.resolve_or_create_music_track(
                db=db,
                music_id=music_id,
                music_title=music_title,
                music_artist=music_artist,
                music_url=music_url,
                music_thumbnail=music_thumbnail,
                music_duration=music_duration,
            )

        story = Story(
            user_id=current_user.id,
            username=current_user.username,
            media_url=media_url,
            media_type=media_type,
            caption=caption,
            audience=normalize_audience(getattr(payload, "audience", "PUBLIC"), is_admin=current_user.is_admin),
            created_at=now_naive,
            expires_at=expires_naive,
            music_id=resolved_music_id,
            music_title=music_title,
            music_artist=music_artist,
            music_url=music_url,
            music_thumbnail=music_thumbnail,
            music_duration=music_duration,
            music_start_time=max(0.0, float(music_start_time)),
        )
        db.add(story)
        db.commit()
        db.refresh(story)
        process_and_create_mentions(db, story, getattr(payload, "mentions", None), caption, current_user)
        logger.info("Story %s created via JSON by user %s", story.story_id, current_user.id)
        return build_story_item(story, current_user.id, db)

    @staticmethod
    def create_text_story(payload, current_user: User, db: Session) -> StoryItemResponse:
        now_naive = make_naive(utc_now())
        duration_hours = getattr(payload, "duration_hours", DEFAULT_DURATION_HOURS) or DEFAULT_DURATION_HOURS
        expires_naive = now_naive + timedelta(hours=duration_hours)

        resolved_music_id = MusicService.resolve_or_create_music_track(
            db=db,
            music_id=getattr(payload, "music_id", None),
            music_title=getattr(payload, "music_title", None),
            music_artist=getattr(payload, "music_artist", None),
            music_url=getattr(payload, "music_url", None),
            music_thumbnail=getattr(payload, "music_thumbnail", None),
            music_duration=getattr(payload, "music_duration", 60.0) or 60.0,
        )

        theme_val = (getattr(payload, "theme", "insta") or "insta").strip().lower()
        media_url = getattr(payload, "media_url", None) or f"gradient:{theme_val}"
        caption_val = getattr(payload, "caption", None) or getattr(payload, "content", None)

        story = Story(
            user_id=current_user.id,
            username=current_user.username,
            media_url=media_url,
            media_type="text",
            caption=caption_val,
            audience=normalize_audience(getattr(payload, "audience", "PUBLIC"), is_admin=current_user.is_admin),
            created_at=now_naive,
            expires_at=expires_naive,
            music_id=resolved_music_id,
            music_title=getattr(payload, "music_title", None),
            music_artist=getattr(payload, "music_artist", None),
            music_url=getattr(payload, "music_url", None),
            music_thumbnail=getattr(payload, "music_thumbnail", None),
            music_duration=getattr(payload, "music_duration", 60.0) or 60.0,
            music_start_time=max(0.0, float(getattr(payload, "music_start_time", 0.0) or 0.0)),
        )
        db.add(story)
        db.commit()
        db.refresh(story)
        process_and_create_mentions(db, story, getattr(payload, "mentions", None), caption_val, current_user)
        return build_story_item(story, current_user.id, db)

    @staticmethod
    def get_owner_feed(current_user: User, db: Session):
        from app.common.schemas.story import SlideOwnerFeedResponse, StoryOwnerFeedResponse

        now_naive = make_naive(utc_now())
        cutoff = now_naive - timedelta(hours=DEFAULT_DURATION_HOURS)

        stories = (
            db.query(Story)
            .filter(
                Story.user_id == current_user.id,
                Story.is_deleted.is_(False),
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
                Story.created_at >= cutoff,
            )
            .order_by(desc(Story.created_at))
            .all()
        )
        if not stories:
            return []

        story_ids = [s.story_id for s in stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user.id, db)

        slides = [
            SlideOwnerFeedResponse(
                id=s.story_id,
                content=s.caption,
                imageUrl=s.media_url,
                media_url=s.media_url,
                views_count=batch_stats["views"].get(s.story_id, 0),
            )
            for s in stories
        ]
        return [
            StoryOwnerFeedResponse(
                story_id=stories[0].story_id,
                username=current_user.username or "Your Story",
                author_id=current_user.id,
                slides=slides,
            )
        ]

    @staticmethod
    def get_privacy_feed(
        current_user: User,
        db: Session,
        limit: int = 20,
        offset: int = 0,
    ) -> List[StoryItemResponse]:
        now_naive = make_naive(utc_now())
        cutoff = now_naive - timedelta(hours=DEFAULT_DURATION_HOURS)

        query = (
            db.query(Story)
            .options(joinedload(Story.owner))
            .filter(
                Story.is_deleted.is_(False),
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
                Story.created_at >= cutoff,
            )
        )

        if not current_user.is_admin:
            following_ids = [
                r[0] for r in db.query(Follow.following_id).filter(Follow.follower_id == current_user.id).all()
            ]
            cf_creator_ids = [
                r[0] for r in db.query(CloseFriend.user_id).filter(CloseFriend.friend_id == current_user.id).all()
            ]
            muted_ids = [
                r[0] for r in db.query(StoryMute.muted_user_id).filter(StoryMute.user_id == current_user.id).all()
            ]

            audience_conditions = [
                func.upper(Story.audience).in_(["PUBLIC"])
            ]
            if following_ids:
                audience_conditions.append(
                    and_(
                        func.upper(Story.audience).in_(["FOLLOWERS", "FOLLOWER"]),
                        Story.user_id.in_(following_ids),
                    )
                )
            if cf_creator_ids:
                audience_conditions.append(
                    and_(
                        func.upper(Story.audience).in_(["CLOSE_FRIENDS", "CLOSE", "CLOSE_FRIEND"]),
                        Story.user_id.in_(cf_creator_ids),
                    )
                )

            privacy_condition = or_(
                Story.user_id == current_user.id,
                and_(
                    ~Story.user_id.in_(muted_ids) if muted_ids else True,
                    or_(*audience_conditions),
                ),
            )
            query = query.filter(privacy_condition)

        stories = (
            query.order_by(desc(Story.created_at))
            .offset(offset)
            .limit(limit)
            .all()
        )
        stories = [s for s in stories if is_story_root_active(s, db, now_naive)]
        story_ids = [s.story_id for s in stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user.id, db)
        return [build_story_item(s, current_user.id, db, batch_stats=batch_stats) for s in stories]

    @staticmethod
    def list_active_groups(
        current_user: Optional[User],
        db: Session,
        role_filter: Optional[str] = None,
    ) -> List[StoryGroupResponse]:
        now_naive = make_naive(utc_now())
        cutoff = now_naive - timedelta(hours=DEFAULT_DURATION_HOURS)

        query = (
            db.query(Story)
            .options(joinedload(Story.owner))
            .filter(
                Story.is_deleted.is_(False),
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
                Story.created_at >= cutoff,
            )
        )

        if role_filter:
            query = query.join(Story.owner).filter(User.role == role_filter)

        active_stories = query.order_by(desc(Story.created_at)).all()
        caller_id = current_user.id if current_user else None
        is_admin = current_user.is_admin if current_user else False

        muted_ids = set()
        following_ids = set()
        cf_creator_ids = set()
        if current_user:
            muted_rows = db.query(StoryMute.muted_user_id).filter(StoryMute.user_id == current_user.id).all()
            muted_ids = {r[0] for r in muted_rows}
            following_rows = db.query(Follow.following_id).filter(Follow.follower_id == current_user.id).all()
            following_ids = {r[0] for r in following_rows}
            cf_rows = db.query(CloseFriend.user_id).filter(CloseFriend.friend_id == current_user.id).all()
            cf_creator_ids = {r[0] for r in cf_rows}

        def can_view(s: Story) -> bool:
            aud = normalize_audience(s.audience)
            if not caller_id:
                return aud == "PUBLIC"
            if s.user_id == caller_id:
                return True
            if s.user_id in muted_ids:
                return False
            if is_admin:
                return True
            if aud == "PUBLIC":
                return True
            if aud == "FOLLOWERS":
                return s.user_id in following_ids
            if aud == "CLOSE_FRIENDS":
                return s.user_id in cf_creator_ids
            return False

        visible_stories = [s for s in active_stories if can_view(s) and is_story_root_active(s, db, now_naive)]

        story_ids = [s.story_id for s in visible_stories]
        batch_stats = fetch_batch_story_stats(story_ids, caller_id, db)

        groups_dict: Dict[int, Dict[str, Any]] = {}
        for story in visible_stories:
            uid = story.user_id
            if uid not in groups_dict:
                user_obj = story.owner
                uname = user_obj.username if user_obj else f"user_{uid}"
                avatar = user_obj.avatar_url if user_obj else None
                user_role = user_obj.role if user_obj else "influencer"
                fname = user_obj.full_name if user_obj else uname

                user_res = StoryUserResponse(
                    id=uid,
                    user_id=uid,
                    username=uname,
                    avatar=avatar,
                    avatar_url=avatar,
                    full_name=fname,
                    role=user_role,
                    verified=user_role in ("influencer", "admin"),
                )
                groups_dict[uid] = {
                    "user": user_res,
                    "stories": [],
                    "latest_dt": story.created_at or now_naive,
                    "music_track": None,
                }

            story_item = build_story_item(story, caller_id, db, batch_stats=batch_stats)
            groups_dict[uid]["stories"].append(story_item)
            if story.music_title and not groups_dict[uid]["music_track"]:
                groups_dict[uid]["music_track"] = f"{story.music_title} – {story.music_artist or 'Tamil Music'} 🎵"

            if story.created_at and story.created_at > groups_dict[uid]["latest_dt"]:
                groups_dict[uid]["latest_dt"] = story.created_at

        result_groups: List[StoryGroupResponse] = []
        for uid, data in groups_dict.items():
            stories_list: List[StoryItemResponse] = data["stories"]
            creator_name = data["user"].username
            slides_list = [story_to_slide(s, creator_name) for s in stories_list]

            all_viewed = all(s.viewed_by_me for s in stories_list) if caller_id else False
            has_unseen = any(not s.viewed_by_me for s in stories_list) if caller_id else True
            is_self = bool(caller_id and uid == caller_id)
            first_story = stories_list[0] if stories_list else None

            result_groups.append(
                StoryGroupResponse(
                    id=uid,
                    user=data["user"],
                    username=creator_name,
                    avatar=data["user"].avatar,
                    verified=data["user"].verified,
                    role=data["user"].role,
                    timeAgo=get_time_ago(data["latest_dt"]),
                    musicTrack=data["music_track"],
                    slides=slides_list,
                    stories=stories_list,
                    stories_count=len(stories_list),
                    latest_story_created_at=format_iso(data["latest_dt"]) or utc_now().isoformat(),
                    is_my_story=is_self,
                    all_viewed=all_viewed,
                    has_unseen_stories=has_unseen,
                    has_active_story=True,
                    media_url=first_story.media_url if first_story else None,
                    story_id=first_story.story_id if first_story else None,
                )
            )

        if caller_id:
            result_groups.sort(key=lambda g: (0 if g.is_my_story else 1, 1 if g.all_viewed else 0))

        return result_groups

    @staticmethod
    def get_my_stories(current_user: User, db: Session) -> List[StoryItemResponse]:
        now_naive = make_naive(utc_now())
        cutoff = now_naive - timedelta(hours=DEFAULT_DURATION_HOURS)

        stories = (
            db.query(Story)
            .options(joinedload(Story.owner))
            .filter(
                Story.user_id == current_user.id,
                Story.is_deleted.is_(False),
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
                Story.created_at >= cutoff,
            )
            .order_by(desc(Story.created_at))
            .all()
        )
        stories = [s for s in stories if is_story_root_active(s, db, now_naive)]
        story_ids = [s.story_id for s in stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user.id, db)
        return [build_story_item(s, current_user.id, db, batch_stats=batch_stats) for s in stories]

    @staticmethod
    def get_user_stories(target_user_id: int, current_user_id: Optional[int], db: Session) -> List[StoryItemResponse]:
        now_naive = make_naive(utc_now())
        cutoff = now_naive - timedelta(hours=DEFAULT_DURATION_HOURS)

        stories = (
            db.query(Story)
            .options(joinedload(Story.owner))
            .filter(
                Story.user_id == target_user_id,
                Story.is_deleted.is_(False),
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
                Story.created_at >= cutoff,
            )
            .order_by(desc(Story.created_at))
            .all()
        )
        if not stories:
            return []

        caller = db.get(User, current_user_id) if current_user_id else None
        is_admin = caller.is_admin if caller else False

        is_following = False
        is_close_friend = False
        if current_user_id and current_user_id != target_user_id:
            is_following = (
                db.query(Follow)
                .filter(Follow.follower_id == current_user_id, Follow.following_id == target_user_id)
                .first()
                is not None
            )
            is_close_friend = (
                db.query(CloseFriend)
                .filter(CloseFriend.user_id == target_user_id, CloseFriend.friend_id == current_user_id)
                .first()
                is not None
            )

        def can_view(s: Story) -> bool:
            if not current_user_id:
                return normalize_audience(s.audience) == "PUBLIC"
            if target_user_id == current_user_id or is_admin:
                return True
            aud = normalize_audience(s.audience)
            if aud == "PUBLIC":
                return True
            if aud == "FOLLOWERS":
                return is_following
            if aud == "CLOSE_FRIENDS":
                return is_close_friend
            return False

        visible_stories = [s for s in stories if can_view(s) and is_story_root_active(s, db, now_naive)]
        story_ids = [s.story_id for s in visible_stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user_id, db)
        return [build_story_item(s, current_user_id, db, batch_stats=batch_stats) for s in visible_stories]

    @staticmethod
    def get_story_by_id(story_id: int, current_user_id: Optional[int], db: Session) -> StoryItemResponse:
        story = db.get(Story, story_id)
        if not story or story.is_deleted:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.expires_at and story.expires_at < make_naive(utc_now()):
            raise HTTPException(status_code=404, detail="Story not found")

        caller = db.get(User, current_user_id) if current_user_id else None
        is_admin = caller.is_admin if caller else False
        aud = normalize_audience(story.audience)

        if caller and (story.user_id == caller.id or is_admin):
            pass
        elif aud == "PUBLIC":
            pass
        elif not caller:
            raise HTTPException(status_code=403, detail="Story is private.")
        elif aud == "FOLLOWERS":
            is_following = db.query(Follow).filter(
                Follow.follower_id == caller.id,
                Follow.following_id == story.user_id,
            ).first() is not None
            if not is_following:
                raise HTTPException(status_code=403, detail="Story only available to followers.")
        elif aud == "CLOSE_FRIENDS":
            is_close_friend = db.query(CloseFriend).filter(
                CloseFriend.user_id == story.user_id,
                CloseFriend.friend_id == caller.id,
            ).first() is not None
            if not is_close_friend:
                raise HTTPException(status_code=403, detail="Story only available to close friends.")

        if story.original_story_id and story.original_story_id != story.story_id:
            root = story.original_story or db.get(Story, story.original_story_id)
            if not root or root.is_deleted or (root.expires_at and root.expires_at <= make_naive(utc_now())):
                raise HTTPException(status_code=404, detail="Story not found or original story expired/deleted.")

        return build_story_item(story, current_user_id, db)

    @staticmethod
    async def upload_single(
        file: UploadFile,
        caption: Optional[str],
        audience: Optional[str],
        music_data: Optional[str],
        current_user: User,
        db: Session,
        music_start_time: Optional[float] = 0.0,
    ) -> StoryItemResponse:
        data_url, media_type = await file_to_base64_data_url(file)

        music_info: Dict[str, Any] = {}
        if music_data:
            try:
                music_info = json.loads(music_data)
            except Exception:
                pass

        now_naive = make_naive(utc_now())
        expires_naive = now_naive + timedelta(hours=DEFAULT_DURATION_HOURS)

        music_dur = None
        resolved_music_id = None
        if music_info:
            music_dur = max(1.0, min(float(music_info.get("music_duration", 60.0)), 60.0))
            resolved_music_id = MusicService.resolve_or_create_music_track(
                db=db,
                music_id=music_info.get("music_id"),
                music_title=music_info.get("music_title") or music_info.get("title"),
                music_artist=music_info.get("music_artist") or music_info.get("artist"),
                music_url=music_info.get("music_url") or music_info.get("audio_url"),
                music_thumbnail=music_info.get("music_thumbnail") or music_info.get("cover_url"),
                music_duration=music_dur,
            )

        story = Story(
            user_id=current_user.id,
            username=current_user.username,
            media_url=data_url,
            media_type=media_type,
            caption=caption,
            audience=normalize_audience(audience, is_admin=current_user.is_admin),
            created_at=now_naive,
            expires_at=expires_naive,
            music_id=resolved_music_id,
            music_title=music_info.get("music_title") or music_info.get("title"),
            music_artist=music_info.get("music_artist") or music_info.get("artist"),
            music_url=music_info.get("music_url") or music_info.get("audio_url"),
            music_thumbnail=music_info.get("music_thumbnail") or music_info.get("cover_url"),
            music_duration=music_dur,
            music_start_time=max(0.0, float(music_start_time or 0.0)),
        )
        db.add(story)
        db.commit()
        db.refresh(story)
        process_and_create_mentions(db, story, None, caption, current_user)
        logger.info("Story %s uploaded by user %s to MySQL demousertable", story.story_id, current_user.id)
        return build_story_item(story, current_user.id, db)

    @staticmethod
    async def upload_multiple(
        files: List[UploadFile],
        captions: Optional[str],
        audience: Optional[str],
        music_data: Optional[str],
        current_user: User,
        db: Session,
        music_start_time: Optional[float] = 0.0,
    ) -> StoryBatchResponse:
        if not files:
            raise HTTPException(status_code=400, detail="No files provided.")

        parsed_captions: List[str] = []
        if captions:
            try:
                parsed = json.loads(captions)
                if isinstance(parsed, list):
                    parsed_captions = [str(c) for c in parsed]
                elif isinstance(parsed, str):
                    parsed_captions = [parsed]
            except Exception:
                parsed_captions = [captions]

        music_info: Dict[str, Any] = {}
        if music_data:
            try:
                music_info = json.loads(music_data)
            except Exception:
                pass

        music_dur = None
        resolved_music_id = None
        if music_info:
            music_dur = max(1.0, min(float(music_info.get("music_duration", 60.0)), 60.0))
            resolved_music_id = MusicService.resolve_or_create_music_track(
                db=db,
                music_id=music_info.get("music_id"),
                music_title=music_info.get("music_title") or music_info.get("title"),
                music_artist=music_info.get("music_artist") or music_info.get("artist"),
                music_url=music_info.get("music_url") or music_info.get("audio_url"),
                music_thumbnail=music_info.get("music_thumbnail") or music_info.get("cover_url"),
                music_duration=music_dur,
            )

        now_naive = make_naive(utc_now())
        expires_naive = now_naive + timedelta(hours=DEFAULT_DURATION_HOURS)

        created_stories: List[Story] = []
        for idx, f in enumerate(files):
            data_url, media_type = await file_to_base64_data_url(f)
            item_caption = parsed_captions[idx] if idx < len(parsed_captions) else (parsed_captions[0] if parsed_captions else None)

            story = Story(
                user_id=current_user.id,
                username=current_user.username,
                media_url=data_url,
                media_type=media_type,
                caption=item_caption,
                audience=normalize_audience(audience, is_admin=current_user.is_admin),
                created_at=now_naive + timedelta(milliseconds=idx * 10),
                expires_at=expires_naive,
                music_id=resolved_music_id,
                music_title=music_info.get("music_title") or music_info.get("title"),
                music_artist=music_info.get("music_artist") or music_info.get("artist"),
                music_url=music_info.get("music_url") or music_info.get("audio_url"),
                music_thumbnail=music_info.get("music_thumbnail") or music_info.get("cover_url"),
                music_duration=music_dur,
                music_start_time=max(0.0, float(music_start_time or 0.0)),
            )
            db.add(story)
            created_stories.append(story)

        db.commit()
        for s in created_stories:
            db.refresh(s)
            process_and_create_mentions(db, s, None, s.caption, current_user)

        items = [build_story_item(s, current_user.id, db) for s in created_stories]
        return StoryBatchResponse(
            success=True,
            message=f"Successfully published {len(created_stories)} stories to MySQL.",
            total_published=len(created_stories),
            stories=items,
        )

    @staticmethod
    def record_view(story_id: int, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        existing = (
            db.query(StoryView)
            .filter(StoryView.story_id == story_id, StoryView.user_id == current_user.id)
            .first()
        )
      
        sender_name = None
        if story.user_id:
            story_owner = db.get(User, story.user_id)
            if story_owner:
                sender_name = story_owner.username
        if not sender_name:
            sender_name = getattr(story, "username", None) or (story.owner.username if story.owner else None)

        if not existing:
            view = StoryView(
                story_id=story_id,
                user_id=current_user.id,
                story_sender=sender_name,
                viewed_by=current_user.username,
                viewed_at=make_naive(utc_now()),
            )
            db.add(view)
            db.commit()
        else:
            updated = False
            if (not existing.story_sender or existing.story_sender != sender_name) and sender_name:
                existing.story_sender = sender_name
                updated = True
            if not existing.viewed_by or existing.viewed_by != current_user.username:
                existing.viewed_by = current_user.username
                updated = True
            if updated:
                db.commit()

        views_count = (
            db.query(func.count(func.distinct(StoryView.user_id)))
            .filter(StoryView.story_id == story_id)
            .scalar() or 0
        )
        return {"success": True, "message": "Story viewed", "story_id": story_id, "views_count": views_count}

    @staticmethod
    def like_story(story_id: int, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.user_id == current_user.id:
            raise HTTPException(status_code=400, detail="Cannot like your own story.")

      
        owner_name = None
        if story.user_id:
            story_owner = db.get(User, story.user_id)
            if story_owner:
                owner_name = story_owner.username
        if not owner_name:
            owner_name = getattr(story, "username", None) or (story.owner.username if story.owner else None)

        existing = (
            db.query(StoryLike)
            .filter(StoryLike.story_id == story_id, StoryLike.user_id == current_user.id)
            .first()
        )
        if not existing:
            like = StoryLike(
                story_id=story_id,
                user_id=current_user.id,
                user_name=owner_name,
                liked_by=current_user.username,
                liked_at=make_naive(utc_now()),
            )
            db.add(like)
            db.commit()

            if story.user_id != current_user.id:
              
                StoryService._notify_story_owner(
                    db, story, "story_like", f"{current_user.username} liked your story"
                )
                StoryService._send_story_message(
                    db, current_user.id, story, MESSAGE_KIND_STORY_REACTION, "\u2764\ufe0f"
                )
        else:
            updated = False
            if (not existing.user_name or existing.user_name != owner_name) and owner_name:
                existing.user_name = owner_name
                updated = True
            if not existing.liked_by or existing.liked_by != current_user.username:
                existing.liked_by = current_user.username
                updated = True
            if updated:
                db.commit()

        likes_count = (
            db.query(func.count(func.distinct(StoryLike.user_id)))
            .filter(StoryLike.story_id == story_id)
            .scalar() or 0
        )
        return {"story_id": story_id, "likes_count": likes_count, "liked_by_me": True, "success": True}

    @staticmethod
    def unlike_story(story_id: int, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        existing = (
            db.query(StoryLike)
            .filter(StoryLike.story_id == story_id, StoryLike.user_id == current_user.id)
            .first()
        )
        if existing:
            db.delete(existing)
          
            if story.user_id != current_user.id:
                try:
                    db.query(Notification).filter(
                        Notification.user_id == story.user_id,
                        Notification.type == "story_like",
                        Notification.reference_id == story_id,
                        Notification.message.like(f"{current_user.username}%"),
                    ).delete(synchronize_session=False)

                   
                    db.query(DirectMessage).filter(
                        DirectMessage.sender_id == current_user.id,
                        DirectMessage.receiver_id == story.user_id,
                        DirectMessage.story_id == story_id,
                        DirectMessage.kind == MESSAGE_KIND_STORY_REACTION,
                        DirectMessage.body == "\u2764\ufe0f",
                    ).delete(synchronize_session=False)
                except Exception:
                    logger.exception("Error cleaning up story_like notification or DM on unlike")

            db.commit()

        likes_count = (
            db.query(func.count(func.distinct(StoryLike.user_id)))
            .filter(StoryLike.story_id == story_id)
            .scalar() or 0
        )
        return {"story_id": story_id, "likes_count": likes_count, "liked_by_me": False, "success": True}

    @staticmethod
    def record_pause_state(
        story_id: int,
        action: str,
        progress_ms: Optional[int],
        slide_index: Optional[int],
        current_user: User,
        db: Session,
    ) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")
        logger.info(
            "User %s %s story %s (slide: %s, progress: %sms)",
            current_user.id,
            action,
            story_id,
            slide_index,
            progress_ms,
        )
        return {
            "success": True,
            "action": action,
            "story_id": story_id,
            "slide_index": slide_index,
            "progress_ms": progress_ms,
            "user_id": current_user.id,
        }

    @staticmethod
    def _send_story_message(db: Session, sender_id: int, story: Story, kind: str, body: str):
        """Best effort: the reply/reaction itself is already saved, so a failure to
        mirror it into chat is logged instead of failing the request."""
        try:
            return MessageService.send_story_message(
                db, sender_id, story.user_id, story.story_id, kind, body
            )
        except Exception:
            db.rollback()
            logger.exception("Could not send story %s as a message (story_id=%s)", kind, story.story_id)
            return None

    @staticmethod
    def _notify_story_owner(db: Session, story: Story, notif_type: str, message: str) -> None:
        try:
            db.add(
                Notification(
                    user_id=story.user_id,
                    type=notif_type,
                    message=message,
                    reference_id=story.story_id,
                    is_read=False,
                    created_at=make_naive(utc_now()),
                )
            )
            db.commit()
        except Exception:
            db.rollback()
            logger.exception("Could not create %s notification (story_id=%s)", notif_type, story.story_id)

    @staticmethod
    def comment_story(story_id: int, text: str, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.user_id == current_user.id:
            raise HTTPException(status_code=400, detail="Cannot reply to your own story.")

        receiver_name = None
        if story.user_id:
            story_owner = db.get(User, story.user_id)
            if story_owner:
                receiver_name = story_owner.username
        if not receiver_name:
            receiver_name = getattr(story, "username", None) or (story.owner.username if story.owner else None)

        sender_name = current_user.username

        reply = StoryReply(
            story_id=story_id,
            user_id=current_user.id,
            sender_name=sender_name,
            receiver_name=receiver_name,
            text=text,
            created_at=make_naive(utc_now()),
        )
        db.add(reply)
        db.commit()
        db.refresh(reply)

        if story.user_id != current_user.id:
            try:
                notif = Notification(
                    user_id=story.user_id,
                    type="story_reply",
                    message=f"{current_user.username} replied to your story: {text[:50]}",
                    reference_id=story_id,
                    is_read=False,
                    created_at=make_naive(utc_now()),
                )
                db.add(notif)
                db.commit()
            except Exception:
                db.rollback()

           
            StoryService._send_story_message(
                db, current_user.id, story, MESSAGE_KIND_STORY_REPLY, text
            )

        return {
            "success": True,
            "message": "Reply sent successfully",
            "reply_id": reply.reply_id,
            "sender_name": reply.sender_name,
            "receiver_name": reply.receiver_name,
            "text": reply.text,
            "created_at": format_iso(reply.created_at) or utc_now().isoformat(),
        }

    @staticmethod
    def get_comments(story_id: int, db: Session) -> List[StoryReplyResponse]:
        replies = (
            db.query(StoryReply)
            .options(joinedload(StoryReply.user))
            .filter(StoryReply.story_id == story_id)
            .order_by(desc(StoryReply.created_at))
            .all()
        )
        return [
            StoryReplyResponse(
                reply_id=r.reply_id,
                story_id=r.story_id,
                user_id=r.user_id,
                text=r.text,
                created_at=format_iso(r.created_at) or utc_now().isoformat(),
                username=r.sender_name or (r.user.username if r.user else f"user_{r.user_id}"),
                sender_name=r.sender_name or (r.user.username if r.user else f"user_{r.user_id}"),
                receiver_name=r.receiver_name,
                avatar_url=r.user.avatar_url if r.user else None,
            )
            for r in replies
        ]

    @staticmethod
    def share_story(
        story_id: int,
        platform: str,
        current_user: User,
        db: Session,
        target_user_id: Optional[int] = None,
    ) -> StoryShareResponse:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        share = StoryShare(
            story_id=story_id,
            user_id=current_user.id,
            platform=platform or "copy_link",
            created_at=make_naive(utc_now()),
        )
        db.add(share)

        if target_user_id and target_user_id != current_user.id:
            try:
                notif = Notification(
                    user_id=target_user_id,
                    type="story_share",
                    message=f"{current_user.username} shared a story with you",
                    reference_id=story_id,
                    is_read=False,
                    created_at=make_naive(utc_now()),
                )
                db.add(notif)
            except Exception:
                pass

        db.commit()
        total_shares = db.query(func.count(StoryShare.share_id)).filter(StoryShare.story_id == story_id).scalar() or 0
        share_url = f"/stories/{story_id}"

        return StoryShareResponse(
            success=True,
            message="Story shared successfully",
            story_id=story_id,
            shares_count=total_shares,
            share_url=share_url,
        )

    @staticmethod
    def report_story(story_id: int, reason: str, current_user: User, db: Session, details: Optional[str] = None) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        existing = db.query(StoryReport).filter(
            StoryReport.story_id == story_id,
            StoryReport.user_id == current_user.id,
        ).first()
        if existing:
            return {"success": True, "message": "You've already reported this story.", "story_id": story_id}

        report = StoryReport(
            story_id=story_id,
            user_id=current_user.id,
            reason=reason[:255] if reason else "Inappropriate content",
            details=details,
            created_at=make_naive(utc_now()),
        )
        db.add(report)
        db.commit()
        return {"success": True, "message": "Thank you. Your report has been submitted.", "story_id": story_id}

    @staticmethod
    def mute_creator(muted_user_id: int, current_user: User, db: Session) -> dict:
        if muted_user_id == current_user.id:
            raise HTTPException(status_code=400, detail="Cannot mute yourself.")

        existing = db.query(StoryMute).filter(
            StoryMute.user_id == current_user.id,
            StoryMute.muted_user_id == muted_user_id,
        ).first()
        if not existing:
            mute = StoryMute(
                user_id=current_user.id,
                muted_user_id=muted_user_id,
                created_at=make_naive(utc_now()),
            )
            db.add(mute)
            db.commit()
        return {
            "success": True,
            "message": "Stories from this user muted.",
            "muted_user_id": muted_user_id,
            "is_muted": True,
        }

    @staticmethod
    def unmute_creator(muted_user_id: int, current_user: User, db: Session) -> dict:
        existing = db.query(StoryMute).filter(
            StoryMute.user_id == current_user.id,
            StoryMute.muted_user_id == muted_user_id,
        ).first()
        if existing:
            db.delete(existing)
            db.commit()
        return {
            "success": True,
            "message": "Stories from this user unmuted.",
            "muted_user_id": muted_user_id,
            "is_muted": False,
        }

    @staticmethod
    def get_muted_creators(current_user: User, db: Session) -> List[int]:
        rows = db.query(StoryMute.muted_user_id).filter(StoryMute.user_id == current_user.id).all()
        return [r[0] for r in rows]

    @staticmethod
    def follow_user(follower_id: int, following_id: int, db: Session) -> dict:
        if follower_id == following_id:
            raise HTTPException(status_code=400, detail="You can't follow yourself.")

        target = db.query(User).filter(User.user_id == following_id).first()
        if target is None:
            raise HTTPException(status_code=404, detail="User not found.")

        follower = db.query(User).filter(User.user_id == follower_id).first()
        if follower is None:
            raise HTTPException(status_code=404, detail="Follower not found.")

        existing = db.query(Follow).filter(
            Follow.follower_id == follower_id,
            Follow.following_id == following_id,
        ).first()

        owner_name = follower.username

        if existing is None:
            db.add(Follow(follower_id=follower_id, following_id=following_id, user_name=owner_name))
            follower._ensure_profile().following_count += 1
            target._ensure_profile().followers_count += 1
            db.commit()
            db.refresh(target)
        else:
            if not existing.user_name and owner_name:
                existing.user_name = owner_name
                db.commit()

        return {
            "success": True,
            "is_following": True,
            "followers_count": target.followers_count,
            "user_name": owner_name,
        }

    @staticmethod
    def unfollow_user(follower_id: int, following_id: int, db: Session) -> dict:
        target = db.query(User).filter(User.user_id == following_id).first()

        existing = db.query(Follow).filter(
            Follow.follower_id == follower_id,
            Follow.following_id == following_id,
        ).first()

        if existing is not None:
            db.delete(existing)
            try:
                db.query(Notification).filter(
                    Notification.user_id == following_id,
                    Notification.type == "follow",
                    Notification.reference_id == follower_id,
                ).delete(synchronize_session=False)
            except Exception:
                pass
            follower = db.query(User).filter(User.user_id == follower_id).first()
            if follower is not None and follower.profile is not None:
                follower.profile.following_count = max(0, follower.profile.following_count - 1)
            if target is not None and target.profile is not None:
                target.profile.followers_count = max(0, target.profile.followers_count - 1)
            db.commit()
            if target is not None:
                db.refresh(target)

        return {
            "success": True,
            "is_following": False,
            "followers_count": target.followers_count if target else 0,
        }


    @staticmethod
    def get_suggestions(current_user: User, db: Session, limit: int = 10) -> List[dict]:
        already_following = db.query(Follow.following_id).filter(
            Follow.follower_id == current_user.id
        )
        candidates = (
            db.query(User)
            .filter(User.user_id != current_user.id)
            .filter(~User.user_id.in_(already_following))
            .order_by(func.rand())
            .limit(limit)
            .all()
        )
        return [
            {
                "id": u.user_id,
                "user_id": u.user_id,
                "username": u.username,
                "full_name": u.full_name,
                "avatar_url": u.avatar_url,
                "role": u.role,
                "bio": u.bio,
                "followers_count": u.followers_count,
                "is_following": False,
            }
            for u in candidates
        ]

    @staticmethod
    def save_story(story_id: int, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        existing = db.query(StorySave).filter(
            StorySave.story_id == story_id,
            StorySave.user_id == current_user.id,
        ).first()

        if not existing:
            save_entry = StorySave(
                story_id=story_id,
                user_id=current_user.id,
                saved_at=make_naive(utc_now()),
            )
            db.add(save_entry)
            db.commit()

        return {
            "success": True,
            "message": "Story saved successfully",
            "story_id": story_id,
            "is_saved": True,
        }

    @staticmethod
    def unsave_story(story_id: int, current_user: User, db: Session) -> dict:
        existing = db.query(StorySave).filter(
            StorySave.story_id == story_id,
            StorySave.user_id == current_user.id,
        ).first()

        if existing:
            db.delete(existing)
            db.commit()

        return {
            "success": True,
            "message": "Story removed from saved",
            "story_id": story_id,
            "is_saved": False,
        }

    @staticmethod
    def get_saved_stories(current_user: User, db: Session) -> list:
        saves = (
            db.query(StorySave)
            .options(joinedload(StorySave.story))
            .filter(StorySave.user_id == current_user.id)
            .order_by(desc(StorySave.saved_at))
            .all()
        )
        return [
            {
                "save_id": s.save_id,
                "story_id": s.story_id,
                "saved_at": format_iso(s.saved_at),
                "media_url": s.story.media_url if s.story else None,
                "caption": s.story.caption if s.story else None,
            }
            for s in saves
            if s.story is not None
        ]

    @staticmethod
    def delete_story(story_id: int, current_user: User, db: Session) -> dict:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        if current_user.id != story.user_id and not current_user.is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only the author who created this story can delete it.",
            )

        now_naive = make_naive(utc_now())
        story.is_deleted = True
        story.deleted_at = now_naive
        story.status = "deleted"

        # Cascade invalidation: when original story is deleted, all derived stories become unavailable!
        derived_stories = db.query(Story).filter(
            or_(
                Story.original_story_id == story_id,
                Story.parent_story_id == story_id,
            ),
            Story.is_deleted == False,
        ).all()
        for ds in derived_stories:
            ds.is_deleted = True
            ds.deleted_at = now_naive
            ds.status = "deleted"

        db.commit()
        logger.info("Story %s (and %s derived stories) deleted by user %s", story_id, len(derived_stories), current_user.id)
        return {"success": True, "message": "Story deleted successfully", "story_id": story_id}

    @staticmethod
    def re_share_story(
        story_id: int,
        payload: Optional[StoryReshareRequest],
        current_user: User,
        db: Session,
    ) -> StoryItemResponse:
        source_story = db.get(Story, story_id)
        if not source_story or source_story.is_deleted:
            raise HTTPException(status_code=404, detail="Story not found or has been deleted.")

        now_naive = make_naive(utc_now())
        if source_story.expires_at and source_story.expires_at <= now_naive:
            raise HTTPException(status_code=400, detail="Cannot re-share an expired story.")

        # Determine original story & original owner
        if source_story.original_story_id and source_story.original_story_id != source_story.story_id:
            root_story = db.get(Story, source_story.original_story_id)
            if not root_story or root_story.is_deleted:
                raise HTTPException(status_code=400, detail="Cannot re-share: original story was deleted.")
            if root_story.expires_at and root_story.expires_at <= now_naive:
                raise HTTPException(status_code=400, detail="Cannot re-share: original story has expired.")
            orig_story_id = root_story.story_id
            orig_owner_id = root_story.user_id
        else:
            orig_story_id = source_story.story_id
            orig_owner_id = source_story.user_id

        # Privacy and Block Check
        for check_uid in {orig_owner_id, source_story.user_id}:
            if check_uid and check_uid != current_user.id:
                is_blocked = db.query(UserBlock).filter(
                    or_(
                        and_(UserBlock.blocker_id == current_user.id, UserBlock.blocked_id == check_uid),
                        and_(UserBlock.blocker_id == check_uid, UserBlock.blocked_id == current_user.id),
                    )
                ).first() is not None
                if is_blocked:
                    raise HTTPException(status_code=403, detail="Cannot re-share this story due to privacy/block restrictions.")

        new_caption = getattr(payload, "caption", None) if payload else None
        if new_caption is None:
            new_caption = getattr(payload, "content", None) if payload else None
        if new_caption is None:
            new_caption = source_story.caption

        audience = normalize_audience(getattr(payload, "audience", "PUBLIC") if payload else "PUBLIC", is_admin=current_user.is_admin)

        new_story = Story(
            user_id=current_user.id,
            username=current_user.username,
            media_url=source_story.media_url,
            media_type=source_story.media_type,
            caption=new_caption,
            audience=audience,
            parent_story_id=source_story.story_id,
            original_story_id=orig_story_id,
            original_owner_id=orig_owner_id,
            status="active",
            created_at=now_naive,
            expires_at=now_naive + timedelta(hours=DEFAULT_DURATION_HOURS),
            music_id=source_story.music_id,
            music_title=source_story.music_title,
            music_artist=source_story.music_artist,
            music_url=source_story.music_url,
            music_thumbnail=source_story.music_thumbnail,
            music_duration=source_story.music_duration,
            music_start_time=source_story.music_start_time,
        )
        db.add(new_story)
        db.commit()
        db.refresh(new_story)

        # Send STORY_SHARED notification ONLY to the original Story owner
        # Never send STORY_SHARED to intermediate sharers!
        if orig_owner_id and orig_owner_id != current_user.id:
            db.add(
                Notification(
                    user_id=orig_owner_id,
                    type="STORY_SHARED",
                    message=f"{current_user.username} shared your story",
                    reference_id=new_story.story_id,
                    is_read=False,
                    created_at=now_naive,
                )
            )
            db.commit()

        # Process any mentions in new re-shared story (e.g. B mentions C)
        mentions_input = getattr(payload, "mentions", None) if payload else None
        process_and_create_mentions(db, new_story, mentions_input, new_caption, current_user)

        return build_story_item(new_story, current_user.id, db)

    @staticmethod
    def search_mention_users(q: str, current_user: User, db: Session, limit: int = 20) -> List[MentionUserSearchItem]:
        query = db.query(User).filter(User.user_id != current_user.id, User.is_active.is_(True))
        term = q.strip().lstrip("@")
        if term:
            like = f"%{term}%"
            query = query.filter(
                or_(
                    User.username.ilike(like),
                    User.first_name.ilike(like),
                    User.last_name.ilike(like),
                    func.concat(User.first_name, " ", User.last_name).ilike(like),
                )
            )
        users = query.order_by(User.first_name.asc(), User.user_id.asc()).limit(limit * 2).all()

        blocked_ids = {
            r[0] for r in db.query(UserBlock.blocked_id).filter(UserBlock.blocker_id == current_user.id).all()
        } | {
            r[0] for r in db.query(UserBlock.blocker_id).filter(UserBlock.blocked_id == current_user.id).all()
        }

        following_ids = {
            r[0] for r in db.query(Follow.following_id).filter(Follow.follower_id == current_user.id).all()
        }

        results = []
        for u in users:
            if u.user_id in blocked_ids:
                continue
            results.append(
                MentionUserSearchItem(
                    id=u.user_id,
                    user_id=u.user_id,
                    username=u.username or f"user_{u.user_id}",
                    full_name=u.full_name or u.username,
                    avatar_url=u.avatar_url,
                    role=u.role or "influencer",
                    is_following=u.user_id in following_ids,
                    is_blocked=False,
                )
            )
            if len(results) >= limit:
                break
        return results

    @staticmethod
    def get_activity(story_id: int, current_user: User, db: Session) -> StoryActivityResponse:
        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        if story.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Only the story author can view viewer activity.")

        likes = db.query(StoryLike).options(joinedload(StoryLike.user)).filter(StoryLike.story_id == story_id).order_by(desc(StoryLike.liked_at)).all()
        likers_list: List[ActivityLiker] = []
        liked_user_ids = set()
        liked_by_me = False
        for l in likes:
            if l.user_id == current_user.id:
                liked_by_me = True
            if l.user_id not in liked_user_ids:
                liked_user_ids.add(l.user_id)
                u = l.user
                liker_name = l.likes_by or (u.username if u else (l.user_name or f"user_{l.user_id}"))
                likers_list.append(
                    ActivityLiker(
                        user_id=l.user_id,
                        username=liker_name,
                        avatar_url=u.avatar_url if u else None,
                        full_name=u.full_name if u else (liker_name or f"User {l.user_id}"),
                    )
                )

        views = (
            db.query(StoryView)
            .options(joinedload(StoryView.user))
            .filter(StoryView.story_id == story_id)
            .order_by(StoryView.viewed_at.asc())
            .all()
        )
        viewers_list: List[ActivityViewer] = []
        seen_viewers = set()
        for v in views:
            if v.user_id not in seen_viewers:
                seen_viewers.add(v.user_id)
                u = v.user
                is_liked = v.user_id in liked_user_ids
                viewer_name = v.viewed_by or (u.username if u else f"user_{v.user_id}")
                viewers_list.append(
                    ActivityViewer(
                        user_id=v.user_id,
                        username=viewer_name,
                        avatar_url=u.avatar_url if u else None,
                        full_name=u.full_name if u else (viewer_name or f"User {v.user_id}"),
                        viewed_at=format_iso(v.viewed_at) or utc_now().isoformat(),
                        liked=is_liked,
                    )
                )

        for l in likes:
            if l.user_id not in seen_viewers:
                seen_viewers.add(l.user_id)
                u = l.user
                viewers_list.append(
                    ActivityViewer(
                        user_id=l.user_id,
                        username=u.username if u else (l.user_name or f"user_{l.user_id}"),
                        avatar_url=u.avatar_url if u else None,
                        full_name=u.full_name if u else (l.user_name or f"User {l.user_id}"),
                        viewed_at=format_iso(l.liked_at) or utc_now().isoformat(),
                        liked=True,
                    )
                )

        viewers_list.sort(key=lambda x: (0 if x.liked else 1))

        return StoryActivityResponse(
            story_id=story_id,
            total_views=len(seen_viewers),
            total_likes=len(likers_list),
            liked_by_me=liked_by_me,
            viewers=viewers_list,
            likers=likers_list,
        )

    @staticmethod
    def get_viewers(
        story_id: int,
        current_user: User,
        db: Session,
        page: int = 1,
        page_size: int = 20,
    ):
        from app.common.schemas.story import PaginatedViewerResponse, StoryViewerItem

        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Only the story owner can see viewers.")

        total = db.query(func.count(StoryView.view_id)).filter(StoryView.story_id == story_id).scalar() or 0
        offset = (page - 1) * page_size
        rows = (
            db.query(StoryView)
            .options(joinedload(StoryView.user))
            .filter(StoryView.story_id == story_id)
            .order_by(desc(StoryView.viewed_at))
            .offset(offset)
            .limit(page_size)
            .all()
        )
        items = [
            StoryViewerItem(
                user_id=v.user_id,
                viewed_by=v.viewed_by or (v.user.username if v.user else f"user_{v.user_id}"),
                username=v.viewed_by or (v.user.username if v.user else f"user_{v.user_id}"),
                story_sender=v.story_sender,
                full_name=v.user.full_name if v.user else None,
                avatar_url=v.user.avatar_url if v.user else None,
                viewed_at=format_iso(v.viewed_at) or utc_now().isoformat(),
            )
            for v in rows
        ]
        return PaginatedViewerResponse(
            story_id=story_id,
            total_views=total,
            page=page,
            page_size=page_size,
            viewers=items,
        )

    @staticmethod
    def get_likers(
        story_id: int,
        current_user: User,
        db: Session,
        page: int = 1,
        page_size: int = 20,
    ):
        from app.common.schemas.story import PaginatedLikerResponse, StoryLikerItem

        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Only the story owner can see likers.")

        total = db.query(func.count(StoryLike.story_likes_id)).filter(StoryLike.story_id == story_id).scalar() or 0
        offset = (page - 1) * page_size
        rows = (
            db.query(StoryLike)
            .options(joinedload(StoryLike.user))
            .filter(StoryLike.story_id == story_id)
            .order_by(desc(StoryLike.liked_at))
            .offset(offset)
            .limit(page_size)
            .all()
        )
        items = [
            StoryLikerItem(
                user_id=lk.user_id,
                liked_by=lk.likes_by or (lk.user.username if lk.user else (lk.user_name or f"user_{lk.user_id}")),
                likes_by=lk.likes_by or (lk.user.username if lk.user else (lk.user_name or f"user_{lk.user_id}")),
                username=lk.likes_by or (lk.user.username if lk.user else (lk.user_name or f"user_{lk.user_id}")),
                full_name=lk.user.full_name if lk.user else None,
                avatar_url=lk.user.avatar_url if lk.user else None,
                liked_at=format_iso(lk.liked_at) or utc_now().isoformat(),
            )
            for lk in rows
        ]
        return PaginatedLikerResponse(
            story_id=story_id,
            total_likes=total,
            page=page,
            page_size=page_size,
            likers=items,
        )

    @staticmethod
    def get_my_stats(current_user: User, db: Session):
        from app.common.schemas.story import StoryStatsResponse

        now_naive = make_naive(utc_now())

        story_ids_rows = db.query(Story.story_id).filter(Story.user_id == current_user.id).all()
        story_ids = [r[0] for r in story_ids_rows]
        total_stories = len(story_ids)

        if not story_ids:
            return StoryStatsResponse(
                user_id=current_user.id,
                total_stories=0,
                total_views=0,
                total_likes=0,
                total_replies=0,
                total_shares=0,
                active_stories=0,
                expired_stories=0,
            )

        total_views = db.query(func.count(StoryView.view_id)).filter(StoryView.story_id.in_(story_ids)).scalar() or 0
        total_likes = db.query(func.count(StoryLike.story_likes_id)).filter(StoryLike.story_id.in_(story_ids)).scalar() or 0
        total_replies = db.query(func.count(StoryReply.reply_id)).filter(StoryReply.story_id.in_(story_ids)).scalar() or 0
        total_shares = db.query(func.count(StoryShare.share_id)).filter(StoryShare.story_id.in_(story_ids)).scalar() or 0

        active_stories = db.query(func.count(Story.story_id)).filter(
            Story.user_id == current_user.id,
            or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
        ).scalar() or 0
        expired_stories = total_stories - active_stories

        return StoryStatsResponse(
            user_id=current_user.id,
            total_stories=total_stories,
            total_views=total_views,
            total_likes=total_likes,
            total_replies=total_replies,
            total_shares=total_shares,
            active_stories=active_stories,
            expired_stories=expired_stories,
        )

    @staticmethod
    def update_story(story_id: int, caption: Optional[str], audience: Optional[Any], current_user: User, db: Session) -> StoryItemResponse:
        story = db.get(Story, story_id)
        if not story or story.is_deleted:
            raise HTTPException(status_code=404, detail="Story not found")
        if story.user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Only the story owner can edit it.")

        if caption is not None:
            story.caption = caption
        if audience is not None:
            story.audience = normalize_audience(audience, is_admin=current_user.is_admin)

        db.commit()
        db.refresh(story)
        return build_story_item(story, current_user.id, db)

    @staticmethod
    def get_archived_stories(current_user: User, db: Session):
        from app.common.schemas.story import StoryArchivedItem

        now_naive = make_naive(utc_now())
        cutoff_30d = now_naive - timedelta(days=30)

        stories = (
            db.query(Story)
            .filter(
                Story.user_id == current_user.id,
                Story.expires_at.isnot(None),
                Story.expires_at <= now_naive,
                Story.created_at >= cutoff_30d,
            )
            .order_by(desc(Story.created_at))
            .all()
        )

        story_ids = [s.story_id for s in stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user.id, db)

        result = [
            StoryArchivedItem(
                story_id=s.story_id,
                id=s.story_id,
                media_url=s.media_url,
                media_type=s.media_type or "image",
                caption=s.caption,
                created_at=format_iso(s.created_at) or utc_now().isoformat(),
                expired_at=format_iso(s.expires_at) or utc_now().isoformat(),
                views_count=batch_stats["views"].get(s.story_id, 0),
                likes_count=batch_stats["likes"].get(s.story_id, 0),
            )
            for s in stories
        ]
        return result

    @staticmethod
    def react_to_story(story_id: int, emoji: str, current_user: User, db: Session) -> dict:
        from app.common.schemas.story import StoryReactResponse

        story = db.get(Story, story_id)
        if not story:
            raise HTTPException(status_code=404, detail="Story not found")

        
        owner_name = None
        if story.user_id:
            story_owner = db.get(User, story.user_id)
            if story_owner:
                owner_name = story_owner.username
        if not owner_name:
            owner_name = getattr(story, "username", None) or (story.owner.username if story.owner else None)

        existing = (
            db.query(StoryLike)
            .filter(
                StoryLike.story_id == story_id,
                StoryLike.user_id == current_user.id,
            )
            .first()
        )
        if not existing:
            db.add(
                StoryLike(
                    story_id=story_id,
                    user_id=current_user.id,
                    user_name=owner_name,
                    liked_by=current_user.username,
                    liked_at=make_naive(utc_now()),
                )
            )
        else:
            if owner_name and existing.user_name != owner_name:
                existing.user_name = owner_name
            if existing.liked_by != current_user.username:
                existing.liked_by = current_user.username
        db.commit()

        if story.user_id != current_user.id:
            sent = StoryService._send_story_message(
                db, current_user.id, story, MESSAGE_KIND_STORY_REACTION, emoji
            )
          
            if sent:
                StoryService._notify_story_owner(
                    db,
                    story,
                    "story_react",
                    f"{current_user.username} reacted {emoji} to your story",
                )

        return StoryReactResponse(
            success=True,
            story_id=story_id,
            emoji=emoji,
            message=f"Reacted with {emoji}",
        )

    @staticmethod
    def get_my_stories_with_metrics(current_user: User, db: Session) -> list:
        from app.common.schemas.story import StoryWithMetrics

        now_naive = make_naive(utc_now())
        cutoff_7d = now_naive - timedelta(days=7)

        stories = (
            db.query(Story)
            .filter(
                Story.user_id == current_user.id,
                Story.created_at >= cutoff_7d,
            )
            .order_by(desc(Story.created_at))
            .all()
        )

        story_ids = [s.story_id for s in stories]
        batch_stats = fetch_batch_story_stats(story_ids, current_user.id, db)

        result = []
        for s in stories:
            views_count = batch_stats["views"].get(s.story_id, 0)
            likes_count = batch_stats["likes"].get(s.story_id, 0)
            replies_count = batch_stats["replies"].get(s.story_id, 0)
            shares_count = batch_stats["shares"].get(s.story_id, 0)
            engagement_rate = round((likes_count + replies_count + shares_count) / views_count * 100, 2) if views_count > 0 else 0.0
            is_active = (s.expires_at is None) or (s.expires_at > now_naive)
            result.append(
                StoryWithMetrics(
                    story_id=s.story_id,
                    id=s.story_id,
                    media_url=s.media_url,
                    media_type=s.media_type or "image",
                    caption=s.caption,
                    audience=s.audience or "public",
                    created_at=format_iso(s.created_at) or utc_now().isoformat(),
                    expires_at=format_iso(s.expires_at) or utc_now().isoformat(),
                    is_active=is_active,
                    views_count=views_count,
                    likes_count=likes_count,
                    replies_count=replies_count,
                    shares_count=shares_count,
                    engagement_rate=engagement_rate,
                )
            )
        return result

    @staticmethod
    def get_my_story_analytics(current_user: User, db: Session) -> Dict[str, Any]:
        now_naive = make_naive(utc_now())

        stories: List[Story] = (
            db.query(Story)
            .options(
                selectinload(Story.views).selectinload(StoryView.user),
                selectinload(Story.likes).selectinload(StoryLike.user),
                selectinload(Story.replies).selectinload(StoryReply.user),
            )
            .filter(
                Story.user_id == current_user.user_id,
                or_(Story.expires_at.is_(None), Story.expires_at > now_naive),
            )
            .order_by(desc(Story.created_at))
            .all()
        )

        def format_user_dict(u: Optional[User]) -> Optional[Dict[str, Any]]:
            if not u:
                return None
            return {
                "id": u.user_id,
                "user_id": u.user_id,
                "username": u.username,
                "email": u.email,
                "full_name": u.full_name,
            }

        stories_data: List[Dict[str, Any]] = []
        total_views_count = 0
        total_likes_count = 0
        total_replies_count = 0

        for story in stories:
            viewers_list = [
                {
                    "view_id": v.view_id,
                    "viewed_at": format_iso(v.viewed_at),
                    "user": format_user_dict(v.user),
                }
                for v in story.views
            ]

            likers_list = [
                {
                    "like_id": lk.story_likes_id,
                    "liked_at": format_iso(lk.liked_at),
                    "user": format_user_dict(lk.user),
                }
                for lk in story.likes
            ]

            replies_list = [
                {
                    "reply_id": r.reply_id,
                    "text": r.text,
                    "created_at": format_iso(r.created_at),
                    "user": format_user_dict(r.user),
                }
                for r in story.replies
            ]

            v_count = len(viewers_list)
            l_count = len(likers_list)
            r_count = len(replies_list)

            total_views_count += v_count
            total_likes_count += l_count
            total_replies_count += r_count

            stories_data.append({
                "story_id": story.story_id,
                "media_url": story.media_url,
                "media_type": story.media_type or "image",
                "caption": story.caption,
                "created_at": format_iso(story.created_at),
                "expires_at": format_iso(story.expires_at),
                "total_views": v_count,
                "total_likes": l_count,
                "total_replies": r_count,
                "viewers": viewers_list,
                "likers": likers_list,
                "replies": replies_list,
            })

        return {
            "summary": {
                "total_active_stories": len(stories_data),
                "total_views": total_views_count,
                "total_likes": total_likes_count,
                "total_replies": total_replies_count,
            },
            "stories": stories_data,
        }